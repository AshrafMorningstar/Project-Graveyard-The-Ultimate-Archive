export default function Home() {
  return (
    <main>
      <h1>Ashraf Morningstar — Web Engineering Projects</h1>
      <p>Beginner to Expert Portfolio</p>
    </main>
  );
}