# SynapseFlow Studio
Visual workflow automation builder by AshrafMorningstar.
GitHub: https://github.com/AshrafMorningstar