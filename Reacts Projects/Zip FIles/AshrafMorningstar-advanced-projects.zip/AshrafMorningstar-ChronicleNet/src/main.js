// ChronicleNet - Main Entry Point
// Author: AshrafMorningstar
// GitHub: https://github.com/AshrafMorningstar