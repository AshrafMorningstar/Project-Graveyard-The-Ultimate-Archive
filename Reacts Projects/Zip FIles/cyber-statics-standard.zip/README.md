# Cyber Statics — Remotion GitHub Stats (Standard)

This project renders a short video showcasing GitHub statistics for a profile (default: `AshrafMorningstar`) with a cyber/neon UI using Remotion and GitHub Actions.
