module.exports = {
  // Minimal Remotion configuration placeholder
};
