# Cyber Statics (Standard Version) — Remotion GitHub Stats Renderer

This PR introduces a redesigned and simplified Remotion GitHub Stats renderer with standard features.
