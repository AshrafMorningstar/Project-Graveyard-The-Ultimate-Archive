import React, { useEffect, useState } from 'react';
import { useStore } from '../../store/useStore';
import { soundService } from '../../utils/sound';

const BootSequence: React.FC = () => {
  const { setBooting } = useStore();
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("INITIALIZING CORE...");
  const [showTitle, setShowTitle] = useState(false);

  useEffect(() => {
    // Reveal title slightly after start
    setTimeout(() => setShowTitle(true), 500);

    const steps = [
      { pct: 15, msg: "LOADING QUANTUM KERNEL..." },
      { pct: 30, msg: "CALIBRATING NEURAL MATRIX..." },
      { pct: 50, msg: "SYNCHRONIZING ASSETS..." },
      { pct: 75, msg: "RENDERING COSMIC INTERFACE..." },
      { pct: 90, msg: "AUTHENTICATING USER..." },
      { pct: 100, msg: "ACCESS GRANTED." },
    ];

    let currentStep = 0;

    const interval = setInterval(() => {
      if (currentStep >= steps.length) {
        clearInterval(interval);
        setTimeout(() => {
            setBooting(false);
            soundService.playOpen();
        }, 1200); // Slightly longer wait at 100% to admire the screen
        return;
      }

      const step = steps[currentStep];
      setProgress(step.pct);
      setStatus(step.msg);
      currentStep++;
    }, 600);

    return () => clearInterval(interval);
  }, [setBooting]);

  return (
    <div className="fixed inset-0 z-[10000] bg-black flex flex-col items-center justify-center overflow-hidden select-none">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(58,12,163,0.15)_0%,rgba(0,0,0,1)_70%)] pointer-events-none" />
      
      <div className="relative z-10 flex flex-col items-center">
          {/* Logo / Spinner Container */}
          <div className="relative mb-12">
            <div className="w-32 h-32 rounded-full border border-white/10 flex items-center justify-center relative">
                <div className="absolute inset-0 rounded-full border-t-2 border-l-2 border-neuro-cyan/50 animate-[spin_3s_linear_infinite]" />
                <div className="absolute inset-2 rounded-full border-r-2 border-b-2 border-neuro-purple/50 animate-[spin_2s_linear_infinite_reverse]" />
                <div className="absolute inset-0 rounded-full shadow-[0_0_30px_rgba(76,201,240,0.1)]" />
                
                {/* Center Icon */}
                <span className="text-5xl text-white font-display animate-pulse">
                    
                </span>
            </div>
          </div>

          {/* Title Section */}
          <div className={`flex flex-col items-center transition-all duration-1000 transform ${showTitle ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <h1 className="text-6xl md:text-7xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-white via-neuro-cyan to-white tracking-tighter mb-2 drop-shadow-[0_0_15px_rgba(0,245,255,0.3)]">
                  MSFOLIO
              </h1>
              <div className="flex items-center gap-3 mb-8">
                  <div className="h-px w-8 bg-neuro-purple/50" />
                  <p className="text-sm md:text-base font-light text-neuro-purple tracking-[0.2em] uppercase">
                      by Ashraf Morningstar
                  </p>
                  <div className="h-px w-8 bg-neuro-purple/50" />
              </div>
          </div>
          
          {/* Progress Bar */}
          <div className="w-64 md:w-80 h-1 bg-white/5 rounded-full overflow-hidden mb-4 relative">
            <div 
                className="h-full bg-gradient-to-r from-neuro-purple to-neuro-cyan shadow-[0_0_15px_#4CC9F0] transition-all duration-500 ease-out relative"
                style={{ width: `${progress}%` }}
            >
                <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/50 blur-[2px]" />
            </div>
          </div>

          {/* Status Text */}
          <div className="h-6 flex items-center justify-center">
            <span className="font-mono text-xs text-neuro-cyan/60 tracking-widest">
                {`> ${status}`}
            </span>
          </div>
      </div>

      {/* Version Number */}
      <div className="absolute bottom-8 text-[10px] font-mono text-white/10 tracking-widest">
          V2.4.1 QUANTUM EDITION
      </div>
    </div>
  );
};

export default BootSequence;