# beginner-events-offline-pwa

ZIP-ready scaffold.
