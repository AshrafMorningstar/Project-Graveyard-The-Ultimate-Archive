module.exports = {
  // Ultra edition may define custom webpack loaders later
};
