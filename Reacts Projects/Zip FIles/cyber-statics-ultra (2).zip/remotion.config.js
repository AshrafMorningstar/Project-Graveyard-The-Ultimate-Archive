module.exports = {
  // Ultra edition may define custom webpack loaders later
  // Keep placeholder to allow Remotion to initialize correctly
};