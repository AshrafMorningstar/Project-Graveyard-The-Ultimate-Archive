# macOS Portfolio OS (Next.js)
Author: Ashraf Morningstar
