// Mac Window Component
