import { create } from "zustand";

interface AppState {
  activeView: "explorer" | "search" | "git" | "debug" | "extensions";
  setActiveView: (
    view: "explorer" | "search" | "git" | "debug" | "extensions"
  ) => void;
  terminalOpen: boolean;
  toggleTerminal: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  activeView: "explorer",
  setActiveView: (view) => set({ activeView: view }),
  terminalOpen: true,
  toggleTerminal: () => set((state) => ({ terminalOpen: !state.terminalOpen })),
}));
