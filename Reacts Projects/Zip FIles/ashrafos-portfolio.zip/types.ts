import React from 'react';

export type AppId = 'finder' | 'projects' | 'ai-chat' | 'tictactoe' | 'settings' | 'browser';

export interface AppConfig {
  id: AppId;
  title: string;
  icon: string; // URL or emoji for simplicity in this proto
  component: React.ComponentType;
  defaultWidth: number;
  defaultHeight: number;
  mobileWidth?: string;
  mobileHeight?: string;
}

export interface WindowState {
  id: AppId;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  zIndex: number;
  position: { x: number; y: number };
  size: { width: number; height: number };
}

export interface Project {
  id: string;
  title: string;
  description: string;
  tech: string[];
  link: string;
  image: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}