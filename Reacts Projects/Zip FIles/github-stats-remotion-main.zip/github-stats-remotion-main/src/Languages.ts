export const Languages = {
	'1C Enterprise': {
		color: 'text-[#814CCC]',
		url: 'https://github.com/trending?l=1C-Enterprise',
	},
	'2-Dimensional Array': {
		color: 'text-[#38761D]',
		url: 'https://github.com/trending?l=2-Dimensional-Array',
	},
	'4D': {
		color: 'text-[#004289]',
		url: 'https://github.com/trending?l=4D',
	},
	ABAP: {
		color: 'text-[#E8274B]',
		url: 'https://github.com/trending?l=ABAP',
	},
	'ABAP CDS': {
		color: 'text-[#555e25]',
		url: 'https://github.com/trending?l=ABAP-CDS',
	},
	ActionScript: {
		color: 'text-[#882B0F]',
		url: 'https://github.com/trending?l=ActionScript',
	},
	Ada: {
		color: 'text-[#02f88c]',
		url: 'https://github.com/trending?l=Ada',
	},
	'Adblock Filter List': {
		color: 'text-[#800000]',
		url: 'https://github.com/trending?l=Adblock-Filter-List',
	},
	'Adobe Font Metrics': {
		color: 'text-[#fa0f00]',
		url: 'https://github.com/trending?l=Adobe-Font-Metrics',
	},
	Agda: {
		color: 'text-[#315665]',
		url: 'https://github.com/trending?l=Agda',
	},
	'AGS Script': {
		color: 'text-[#B9D9FF]',
		url: 'https://github.com/trending?l=AGS-Script',
	},
	AIDL: {
		color: 'text-[#34EB6B]',
		url: 'https://github.com/trending?l=AIDL',
	},
	AL: {
		color: 'text-[#3AA2B5]',
		url: 'https://github.com/trending?l=AL',
	},
	Alloy: {
		color: 'text-[#64C800]',
		url: 'https://github.com/trending?l=Alloy',
	},
	'Alpine Abuild': {
		color: 'text-[#0D597F]',
		url: 'https://github.com/trending?l=Alpine-Abuild',
	},
	'Altium Designer': {
		color: 'text-[#A89663]',
		url: 'https://github.com/trending?l=Altium-Designer',
	},
	AMPL: {
		color: 'text-[#E6EFBB]',
		url: 'https://github.com/trending?l=AMPL',
	},
	AngelScript: {
		color: 'text-[#C7D7DC]',
		url: 'https://github.com/trending?l=AngelScript',
	},
	'Ant Build System': {
		color: 'text-[#A9157E]',
		url: 'https://github.com/trending?l=Ant-Build-System',
	},
	Antlers: {
		color: 'text-[#ff269e]',
		url: 'https://github.com/trending?l=Antlers',
	},
	ANTLR: {
		color: 'text-[#9DC3FF]',
		url: 'https://github.com/trending?l=ANTLR',
	},
	ApacheConf: {
		color: 'text-[#d12127]',
		url: 'https://github.com/trending?l=ApacheConf',
	},
	Apex: {
		color: 'text-[#1797c0]',
		url: 'https://github.com/trending?l=Apex',
	},
	'API Blueprint': {
		color: 'text-[#2ACCA8]',
		url: 'https://github.com/trending?l=API-Blueprint',
	},
	APL: {
		color: 'text-[#5A8164]',
		url: 'https://github.com/trending?l=APL',
	},
	'Apollo Guidance Computer': {
		color: 'text-[#0B3D91]',
		url: 'https://github.com/trending?l=Apollo-Guidance-Computer',
	},
	AppleScript: {
		color: 'text-[#101F1F]',
		url: 'https://github.com/trending?l=AppleScript',
	},
	Arc: {
		color: 'text-[#aa2afe]',
		url: 'https://github.com/trending?l=Arc',
	},
	AsciiDoc: {
		color: 'text-[#73a0c5]',
		url: 'https://github.com/trending?l=AsciiDoc',
	},
	ASL: {
		color: null,
		url: 'https://github.com/trending?l=ASL',
	},
	'ASP.NET': {
		color: 'text-[#9400ff]',
		url: 'https://github.com/trending?l=ASP.NET',
	},
	AspectJ: {
		color: 'text-[#a957b0]',
		url: 'https://github.com/trending?l=AspectJ',
	},
	Assembly: {
		color: 'text-[#6E4C13]',
		url: 'https://github.com/trending?l=Assembly',
	},
	Astro: {
		color: 'text-[#ff5a03]',
		url: 'https://github.com/trending?l=Astro',
	},
	Asymptote: {
		color: 'text-[#ff0000]',
		url: 'https://github.com/trending?l=Asymptote',
	},
	ATS: {
		color: 'text-[#1ac620]',
		url: 'https://github.com/trending?l=ATS',
	},
	Augeas: {
		color: 'text-[#9CC134]',
		url: 'https://github.com/trending?l=Augeas',
	},
	AutoHotkey: {
		color: 'text-[#6594b9]',
		url: 'https://github.com/trending?l=AutoHotkey',
	},
	AutoIt: {
		color: 'text-[#1C3552]',
		url: 'https://github.com/trending?l=AutoIt',
	},
	'Avro IDL': {
		color: 'text-[#0040FF]',
		url: 'https://github.com/trending?l=Avro-IDL',
	},
	Awk: {
		color: 'text-[#c30e9b]',
		url: 'https://github.com/trending?l=Awk',
	},
	Ballerina: {
		color: 'text-[#FF5000]',
		url: 'https://github.com/trending?l=Ballerina',
	},
	BASIC: {
		color: 'text-[#ff0000]',
		url: 'https://github.com/trending?l=BASIC',
	},
	Batchfile: {
		color: 'text-[#C1F12E]',
		url: 'https://github.com/trending?l=Batchfile',
	},
	Beef: {
		color: 'text-[#a52f4e]',
		url: 'https://github.com/trending?l=Beef',
	},
	Befunge: {
		color: null,
		url: 'https://github.com/trending?l=Befunge',
	},
	Berry: {
		color: 'text-[#15A13C]',
		url: 'https://github.com/trending?l=Berry',
	},
	BibTeX: {
		color: 'text-[#778899]',
		url: 'https://github.com/trending?l=BibTeX',
	},
	Bicep: {
		color: 'text-[#519aba]',
		url: 'https://github.com/trending?l=Bicep',
	},
	Bikeshed: {
		color: 'text-[#5562ac]',
		url: 'https://github.com/trending?l=Bikeshed',
	},
	Bison: {
		color: 'text-[#6A463F]',
		url: 'https://github.com/trending?l=Bison',
	},
	BitBake: {
		color: 'text-[#00bce4]',
		url: 'https://github.com/trending?l=BitBake',
	},
	Blade: {
		color: 'text-[#f7523f]',
		url: 'https://github.com/trending?l=Blade',
	},
	BlitzBasic: {
		color: 'text-[#00FFAE]',
		url: 'https://github.com/trending?l=BlitzBasic',
	},
	BlitzMax: {
		color: 'text-[#cd6400]',
		url: 'https://github.com/trending?l=BlitzMax',
	},
	Bluespec: {
		color: 'text-[#12223c]',
		url: 'https://github.com/trending?l=Bluespec',
	},
	'Bluespec BH': {
		color: 'text-[#12223c]',
		url: 'https://github.com/trending?l=Bluespec-BH',
	},
	Boo: {
		color: 'text-[#d4bec1]',
		url: 'https://github.com/trending?l=Boo',
	},
	Boogie: {
		color: 'text-[#c80fa0]',
		url: 'https://github.com/trending?l=Boogie',
	},
	Brainfuck: {
		color: 'text-[#2F2530]',
		url: 'https://github.com/trending?l=Brainfuck',
	},
	BrighterScript: {
		color: 'text-[#66AABB]',
		url: 'https://github.com/trending?l=BrighterScript',
	},
	Brightscript: {
		color: 'text-[#662D91]',
		url: 'https://github.com/trending?l=Brightscript',
	},
	Browserslist: {
		color: 'text-[#ffd539]',
		url: 'https://github.com/trending?l=Browserslist',
	},
	C: {
		color: 'text-[#555555]',
		url: 'https://github.com/trending?l=C',
	},
	'C#': {
		color: 'text-[#178600]',
		url: 'https://github.com/trending?l=Csharp',
	},
	'C++': {
		color: 'text-[#f34b7d]',
		url: 'https://github.com/trending?l=C++',
	},
	'C2hs Haskell': {
		color: null,
		url: 'https://github.com/trending?l=C2hs-Haskell',
	},
	'Cabal Config': {
		color: 'text-[#483465]',
		url: 'https://github.com/trending?l=Cabal-Config',
	},
	Cadence: {
		color: 'text-[#00ef8b]',
		url: 'https://github.com/trending?l=Cadence',
	},
	Cairo: {
		color: 'text-[#ff4a48]',
		url: 'https://github.com/trending?l=Cairo',
	},
	CameLIGO: {
		color: 'text-[#3be133]',
		url: 'https://github.com/trending?l=CameLIGO',
	},
	'CAP CDS': {
		color: 'text-[#0092d1]',
		url: 'https://github.com/trending?l=CAP-CDS',
	},
	"Cap'n Proto": {
		color: 'text-[#c42727]',
		url: "https://github.com/trending?l=Cap'n-Proto",
	},
	CartoCSS: {
		color: null,
		url: 'https://github.com/trending?l=CartoCSS',
	},
	Ceylon: {
		color: 'text-[#dfa535]',
		url: 'https://github.com/trending?l=Ceylon',
	},
	Chapel: {
		color: 'text-[#8dc63f]',
		url: 'https://github.com/trending?l=Chapel',
	},
	Charity: {
		color: null,
		url: 'https://github.com/trending?l=Charity',
	},
	ChucK: {
		color: 'text-[#3f8000]',
		url: 'https://github.com/trending?l=ChucK',
	},
	Circom: {
		color: 'text-[#707575]',
		url: 'https://github.com/trending?l=Circom',
	},
	Cirru: {
		color: 'text-[#ccccff]',
		url: 'https://github.com/trending?l=Cirru',
	},
	Clarion: {
		color: 'text-[#db901e]',
		url: 'https://github.com/trending?l=Clarion',
	},
	Clarity: {
		color: 'text-[#5546ff]',
		url: 'https://github.com/trending?l=Clarity',
	},
	'Classic ASP': {
		color: 'text-[#6a40fd]',
		url: 'https://github.com/trending?l=Classic-ASP',
	},
	Clean: {
		color: 'text-[#3F85AF]',
		url: 'https://github.com/trending?l=Clean',
	},
	Click: {
		color: 'text-[#E4E6F3]',
		url: 'https://github.com/trending?l=Click',
	},
	CLIPS: {
		color: 'text-[#00A300]',
		url: 'https://github.com/trending?l=CLIPS',
	},
	Clojure: {
		color: 'text-[#db5855]',
		url: 'https://github.com/trending?l=Clojure',
	},
	'Closure Templates': {
		color: 'text-[#0d948f]',
		url: 'https://github.com/trending?l=Closure-Templates',
	},
	'Cloud Firestore Security Rules': {
		color: 'text-[#FFA000]',
		url: 'https://github.com/trending?l=Cloud-Firestore-Security-Rules',
	},
	CMake: {
		color: 'text-[#DA3434]',
		url: 'https://github.com/trending?l=CMake',
	},
	COBOL: {
		color: null,
		url: 'https://github.com/trending?l=COBOL',
	},
	CodeQL: {
		color: 'text-[#140f46]',
		url: 'https://github.com/trending?l=CodeQL',
	},
	CoffeeScript: {
		color: 'text-[#244776]',
		url: 'https://github.com/trending?l=CoffeeScript',
	},
	ColdFusion: {
		color: 'text-[#ed2cd6]',
		url: 'https://github.com/trending?l=ColdFusion',
	},
	'ColdFusion CFC': {
		color: 'text-[#ed2cd6]',
		url: 'https://github.com/trending?l=ColdFusion-CFC',
	},
	COLLADA: {
		color: 'text-[#F1A42B]',
		url: 'https://github.com/trending?l=COLLADA',
	},
	'Common Lisp': {
		color: 'text-[#3fb68b]',
		url: 'https://github.com/trending?l=Common-Lisp',
	},
	'Common Workflow Language': {
		color: 'text-[#B5314C]',
		url: 'https://github.com/trending?l=Common-Workflow-Language',
	},
	'Component Pascal': {
		color: 'text-[#B0CE4E]',
		url: 'https://github.com/trending?l=Component-Pascal',
	},
	Cool: {
		color: null,
		url: 'https://github.com/trending?l=Cool',
	},
	Coq: {
		color: 'text-[#d0b68c]',
		url: 'https://github.com/trending?l=Coq',
	},
	Crystal: {
		color: 'text-[#000100]',
		url: 'https://github.com/trending?l=Crystal',
	},
	CSON: {
		color: 'text-[#244776]',
		url: 'https://github.com/trending?l=CSON',
	},
	Csound: {
		color: 'text-[#1a1a1a]',
		url: 'https://github.com/trending?l=Csound',
	},
	'Csound Document': {
		color: 'text-[#1a1a1a]',
		url: 'https://github.com/trending?l=Csound-Document',
	},
	'Csound Score': {
		color: 'text-[#1a1a1a]',
		url: 'https://github.com/trending?l=Csound-Score',
	},
	CSS: {
		color: 'text-[#563d7c]',
		url: 'https://github.com/trending?l=CSS',
	},
	CSV: {
		color: 'text-[#237346]',
		url: 'https://github.com/trending?l=CSV',
	},
	Cuda: {
		color: 'text-[#3A4E3A]',
		url: 'https://github.com/trending?l=Cuda',
	},
	CUE: {
		color: 'text-[#5886E1]',
		url: 'https://github.com/trending?l=CUE',
	},
	Curry: {
		color: 'text-[#531242]',
		url: 'https://github.com/trending?l=Curry',
	},
	CWeb: {
		color: 'text-[#00007a]',
		url: 'https://github.com/trending?l=CWeb',
	},
	Cycript: {
		color: null,
		url: 'https://github.com/trending?l=Cycript',
	},
	Cypher: {
		color: 'text-[#34c0eb]',
		url: 'https://github.com/trending?l=Cypher',
	},
	Cython: {
		color: 'text-[#fedf5b]',
		url: 'https://github.com/trending?l=Cython',
	},
	D: {
		color: 'text-[#ba595e]',
		url: 'https://github.com/trending?l=D',
	},
	D2: {
		color: 'text-[#526ee8]',
		url: 'https://github.com/trending?l=D2',
	},
	Dafny: {
		color: 'text-[#FFEC25]',
		url: 'https://github.com/trending?l=Dafny',
	},
	'Darcs Patch': {
		color: 'text-[#8eff23]',
		url: 'https://github.com/trending?l=Darcs-Patch',
	},
	Dart: {
		color: 'text-[#00B4AB]',
		url: 'https://github.com/trending?l=Dart',
	},
	DataWeave: {
		color: 'text-[#003a52]',
		url: 'https://github.com/trending?l=DataWeave',
	},
	'Debian Package Control File': {
		color: 'text-[#D70751]',
		url: 'https://github.com/trending?l=Debian-Package-Control-File',
	},
	DenizenScript: {
		color: 'text-[#FBEE96]',
		url: 'https://github.com/trending?l=DenizenScript',
	},
	Dhall: {
		color: 'text-[#dfafff]',
		url: 'https://github.com/trending?l=Dhall',
	},
	'DIGITAL Command Language': {
		color: null,
		url: 'https://github.com/trending?l=DIGITAL-Command-Language',
	},
	'DirectX 3D File': {
		color: 'text-[#aace60]',
		url: 'https://github.com/trending?l=DirectX-3D-File',
	},
	DM: {
		color: 'text-[#447265]',
		url: 'https://github.com/trending?l=DM',
	},
	Dockerfile: {
		color: 'text-[#384d54]',
		url: 'https://github.com/trending?l=Dockerfile',
	},
	Dogescript: {
		color: 'text-[#cca760]',
		url: 'https://github.com/trending?l=Dogescript',
	},
	Dotenv: {
		color: 'text-[#e5d559]',
		url: 'https://github.com/trending?l=Dotenv',
	},
	DTrace: {
		color: null,
		url: 'https://github.com/trending?l=DTrace',
	},
	Dylan: {
		color: 'text-[#6c616e]',
		url: 'https://github.com/trending?l=Dylan',
	},
	E: {
		color: 'text-[#ccce35]',
		url: 'https://github.com/trending?l=E',
	},
	Earthly: {
		color: 'text-[#2af0ff]',
		url: 'https://github.com/trending?l=Earthly',
	},
	Easybuild: {
		color: 'text-[#069406]',
		url: 'https://github.com/trending?l=Easybuild',
	},
	eC: {
		color: 'text-[#913960]',
		url: 'https://github.com/trending?l=eC',
	},
	'Ecere Projects': {
		color: 'text-[#913960]',
		url: 'https://github.com/trending?l=Ecere-Projects',
	},
	ECL: {
		color: 'text-[#8a1267]',
		url: 'https://github.com/trending?l=ECL',
	},
	ECLiPSe: {
		color: 'text-[#001d9d]',
		url: 'https://github.com/trending?l=ECLiPSe',
	},
	Ecmarkup: {
		color: 'text-[#eb8131]',
		url: 'https://github.com/trending?l=Ecmarkup',
	},
	EdgeQL: {
		color: 'text-[#31A7FF]',
		url: 'https://github.com/trending?l=EdgeQL',
	},
	EditorConfig: {
		color: 'text-[#fff1f2]',
		url: 'https://github.com/trending?l=EditorConfig',
	},
	Eiffel: {
		color: 'text-[#4d6977]',
		url: 'https://github.com/trending?l=Eiffel',
	},
	EJS: {
		color: 'text-[#a91e50]',
		url: 'https://github.com/trending?l=EJS',
	},
	Elixir: {
		color: 'text-[#6e4a7e]',
		url: 'https://github.com/trending?l=Elixir',
	},
	Elm: {
		color: 'text-[#60B5CC]',
		url: 'https://github.com/trending?l=Elm',
	},
	Elvish: {
		color: 'text-[#55BB55]',
		url: 'https://github.com/trending?l=Elvish',
	},
	'Elvish Transcript': {
		color: 'text-[#55BB55]',
		url: 'https://github.com/trending?l=Elvish-Transcript',
	},
	'Emacs Lisp': {
		color: 'text-[#c065db]',
		url: 'https://github.com/trending?l=Emacs-Lisp',
	},
	EmberScript: {
		color: 'text-[#FFF4F3]',
		url: 'https://github.com/trending?l=EmberScript',
	},
	EQ: {
		color: 'text-[#a78649]',
		url: 'https://github.com/trending?l=EQ',
	},
	Erlang: {
		color: 'text-[#B83998]',
		url: 'https://github.com/trending?l=Erlang',
	},
	Euphoria: {
		color: 'text-[#FF790B]',
		url: 'https://github.com/trending?l=Euphoria',
	},
	'F#': {
		color: 'text-[#b845fc]',
		url: 'https://github.com/trending?l=Fsharp',
	},
	'F*': {
		color: 'text-[#572e30]',
		url: 'https://github.com/trending?l=F*',
	},
	Factor: {
		color: 'text-[#636746]',
		url: 'https://github.com/trending?l=Factor',
	},
	Fancy: {
		color: 'text-[#7b9db4]',
		url: 'https://github.com/trending?l=Fancy',
	},
	Fantom: {
		color: 'text-[#14253c]',
		url: 'https://github.com/trending?l=Fantom',
	},
	Faust: {
		color: 'text-[#c37240]',
		url: 'https://github.com/trending?l=Faust',
	},
	Fennel: {
		color: 'text-[#fff3d7]',
		url: 'https://github.com/trending?l=Fennel',
	},
	'FIGlet Font': {
		color: 'text-[#FFDDBB]',
		url: 'https://github.com/trending?l=FIGlet-Font',
	},
	'Filebench WML': {
		color: 'text-[#F6B900]',
		url: 'https://github.com/trending?l=Filebench-WML',
	},
	Filterscript: {
		color: null,
		url: 'https://github.com/trending?l=Filterscript',
	},
	fish: {
		color: 'text-[#4aae47]',
		url: 'https://github.com/trending?l=fish',
	},
	Fluent: {
		color: 'text-[#ffcc33]',
		url: 'https://github.com/trending?l=Fluent',
	},
	FLUX: {
		color: 'text-[#88ccff]',
		url: 'https://github.com/trending?l=FLUX',
	},
	Forth: {
		color: 'text-[#341708]',
		url: 'https://github.com/trending?l=Forth',
	},
	Fortran: {
		color: 'text-[#4d41b1]',
		url: 'https://github.com/trending?l=Fortran',
	},
	'Fortran Free Form': {
		color: 'text-[#4d41b1]',
		url: 'https://github.com/trending?l=Fortran-Free-Form',
	},
	FreeBasic: {
		color: 'text-[#141AC9]',
		url: 'https://github.com/trending?l=FreeBasic',
	},
	FreeMarker: {
		color: 'text-[#0050b2]',
		url: 'https://github.com/trending?l=FreeMarker',
	},
	Frege: {
		color: 'text-[#00cafe]',
		url: 'https://github.com/trending?l=Frege',
	},
	Futhark: {
		color: 'text-[#5f021f]',
		url: 'https://github.com/trending?l=Futhark',
	},
	'G-code': {
		color: 'text-[#D08CF2]',
		url: 'https://github.com/trending?l=G-code',
	},
	'Game Maker Language': {
		color: 'text-[#71b417]',
		url: 'https://github.com/trending?l=Game-Maker-Language',
	},
	GAML: {
		color: 'text-[#FFC766]',
		url: 'https://github.com/trending?l=GAML',
	},
	GAMS: {
		color: 'text-[#f49a22]',
		url: 'https://github.com/trending?l=GAMS',
	},
	GAP: {
		color: 'text-[#0000cc]',
		url: 'https://github.com/trending?l=GAP',
	},
	'GCC Machine Description': {
		color: 'text-[#FFCFAB]',
		url: 'https://github.com/trending?l=GCC-Machine-Description',
	},
	GDB: {
		color: null,
		url: 'https://github.com/trending?l=GDB',
	},
	GDScript: {
		color: 'text-[#355570]',
		url: 'https://github.com/trending?l=GDScript',
	},
	GEDCOM: {
		color: 'text-[#003058]',
		url: 'https://github.com/trending?l=GEDCOM',
	},
	'Gemfile.lock': {
		color: 'text-[#701516]',
		url: 'https://github.com/trending?l=Gemfile.lock',
	},
	Gemini: {
		color: 'text-[#ff6900]',
		url: 'https://github.com/trending?l=Gemini',
	},
	'Genero 4gl': {
		color: 'text-[#63408e]',
		url: 'https://github.com/trending?l=Genero-4gl',
	},
	'Genero per': {
		color: 'text-[#d8df39]',
		url: 'https://github.com/trending?l=Genero-per',
	},
	Genie: {
		color: 'text-[#fb855d]',
		url: 'https://github.com/trending?l=Genie',
	},
	Genshi: {
		color: 'text-[#951531]',
		url: 'https://github.com/trending?l=Genshi',
	},
	'Gentoo Ebuild': {
		color: 'text-[#9400ff]',
		url: 'https://github.com/trending?l=Gentoo-Ebuild',
	},
	'Gentoo Eclass': {
		color: 'text-[#9400ff]',
		url: 'https://github.com/trending?l=Gentoo-Eclass',
	},
	'Gerber Image': {
		color: 'text-[#d20b00]',
		url: 'https://github.com/trending?l=Gerber-Image',
	},
	Gherkin: {
		color: 'text-[#5B2063]',
		url: 'https://github.com/trending?l=Gherkin',
	},
	'Git Attributes': {
		color: 'text-[#F44D27]',
		url: 'https://github.com/trending?l=Git-Attributes',
	},
	'Git Config': {
		color: 'text-[#F44D27]',
		url: 'https://github.com/trending?l=Git-Config',
	},
	'Git Revision List': {
		color: 'text-[#F44D27]',
		url: 'https://github.com/trending?l=Git-Revision-List',
	},
	Gleam: {
		color: 'text-[#ffaff3]',
		url: 'https://github.com/trending?l=Gleam',
	},
	'Glimmer JS': {
		color: 'text-[#F5835F]',
		url: 'https://github.com/trending?l=Glimmer-JS',
	},
	GLSL: {
		color: 'text-[#5686a5]',
		url: 'https://github.com/trending?l=GLSL',
	},
	Glyph: {
		color: 'text-[#c1ac7f]',
		url: 'https://github.com/trending?l=Glyph',
	},
	Gnuplot: {
		color: 'text-[#f0a9f0]',
		url: 'https://github.com/trending?l=Gnuplot',
	},
	Go: {
		color: 'text-[#00ADD8]',
		url: 'https://github.com/trending?l=Go',
	},
	'Go Checksums': {
		color: 'text-[#00ADD8]',
		url: 'https://github.com/trending?l=Go-Checksums',
	},
	'Go Module': {
		color: 'text-[#00ADD8]',
		url: 'https://github.com/trending?l=Go-Module',
	},
	'Go Workspace': {
		color: 'text-[#00ADD8]',
		url: 'https://github.com/trending?l=Go-Workspace',
	},
	'Godot Resource': {
		color: 'text-[#355570]',
		url: 'https://github.com/trending?l=Godot-Resource',
	},
	Golo: {
		color: 'text-[#88562A]',
		url: 'https://github.com/trending?l=Golo',
	},
	Gosu: {
		color: 'text-[#82937f]',
		url: 'https://github.com/trending?l=Gosu',
	},
	Grace: {
		color: 'text-[#615f8b]',
		url: 'https://github.com/trending?l=Grace',
	},
	Gradle: {
		color: 'text-[#02303a]',
		url: 'https://github.com/trending?l=Gradle',
	},
	'Gradle Kotlin DSL': {
		color: 'text-[#02303a]',
		url: 'https://github.com/trending?l=Gradle-Kotlin-DSL',
	},
	'Grammatical Framework': {
		color: 'text-[#ff0000]',
		url: 'https://github.com/trending?l=Grammatical-Framework',
	},
	GraphQL: {
		color: 'text-[#e10098]',
		url: 'https://github.com/trending?l=GraphQL',
	},
	'Graphviz (DOT)': {
		color: 'text-[#2596be]',
		url: 'https://github.com/trending?l=Graphviz-(DOT)',
	},
	Groovy: {
		color: 'text-[#4298b8]',
		url: 'https://github.com/trending?l=Groovy',
	},
	'Groovy Server Pages': {
		color: 'text-[#4298b8]',
		url: 'https://github.com/trending?l=Groovy-Server-Pages',
	},
	GSC: {
		color: 'text-[#FF6800]',
		url: 'https://github.com/trending?l=GSC',
	},
	Hack: {
		color: 'text-[#878787]',
		url: 'https://github.com/trending?l=Hack',
	},
	Haml: {
		color: 'text-[#ece2a9]',
		url: 'https://github.com/trending?l=Haml',
	},
	Handlebars: {
		color: 'text-[#f7931e]',
		url: 'https://github.com/trending?l=Handlebars',
	},
	HAProxy: {
		color: 'text-[#106da9]',
		url: 'https://github.com/trending?l=HAProxy',
	},
	Harbour: {
		color: 'text-[#0e60e3]',
		url: 'https://github.com/trending?l=Harbour',
	},
	Haskell: {
		color: 'text-[#5e5086]',
		url: 'https://github.com/trending?l=Haskell',
	},
	Haxe: {
		color: 'text-[#df7900]',
		url: 'https://github.com/trending?l=Haxe',
	},
	HCL: {
		color: 'text-[#844FBA]',
		url: 'https://github.com/trending?l=HCL',
	},
	HiveQL: {
		color: 'text-[#dce200]',
		url: 'https://github.com/trending?l=HiveQL',
	},
	HLSL: {
		color: 'text-[#aace60]',
		url: 'https://github.com/trending?l=HLSL',
	},
	HOCON: {
		color: 'text-[#9ff8ee]',
		url: 'https://github.com/trending?l=HOCON',
	},
	HolyC: {
		color: 'text-[#ffefaf]',
		url: 'https://github.com/trending?l=HolyC',
	},
	hoon: {
		color: 'text-[#00b171]',
		url: 'https://github.com/trending?l=hoon',
	},
	'Hosts File': {
		color: 'text-[#308888]',
		url: 'https://github.com/trending?l=Hosts-File',
	},
	HTML: {
		color: 'text-[#e34c26]',
		url: 'https://github.com/trending?l=HTML',
	},
	'HTML+ECR': {
		color: 'text-[#2e1052]',
		url: 'https://github.com/trending?l=HTML+ECR',
	},
	'HTML+EEX': {
		color: 'text-[#6e4a7e]',
		url: 'https://github.com/trending?l=HTML+EEX',
	},
	'HTML+ERB': {
		color: 'text-[#701516]',
		url: 'https://github.com/trending?l=HTML+ERB',
	},
	'HTML+PHP': {
		color: 'text-[#4f5d95]',
		url: 'https://github.com/trending?l=HTML+PHP',
	},
	'HTML+Razor': {
		color: 'text-[#512be4]',
		url: 'https://github.com/trending?l=HTML+Razor',
	},
	HTTP: {
		color: 'text-[#005C9C]',
		url: 'https://github.com/trending?l=HTTP',
	},
	HXML: {
		color: 'text-[#f68712]',
		url: 'https://github.com/trending?l=HXML',
	},
	Hy: {
		color: 'text-[#7790B2]',
		url: 'https://github.com/trending?l=Hy',
	},
	HyPhy: {
		color: null,
		url: 'https://github.com/trending?l=HyPhy',
	},
	IDL: {
		color: 'text-[#a3522f]',
		url: 'https://github.com/trending?l=IDL',
	},
	Idris: {
		color: 'text-[#b30000]',
		url: 'https://github.com/trending?l=Idris',
	},
	'Ignore List': {
		color: 'text-[#000000]',
		url: 'https://github.com/trending?l=Ignore-List',
	},
	'IGOR Pro': {
		color: 'text-[#0000cc]',
		url: 'https://github.com/trending?l=IGOR-Pro',
	},
	'ImageJ Macro': {
		color: 'text-[#99AAFF]',
		url: 'https://github.com/trending?l=ImageJ-Macro',
	},
	Imba: {
		color: 'text-[#16cec6]',
		url: 'https://github.com/trending?l=Imba',
	},
	'Inform 7': {
		color: null,
		url: 'https://github.com/trending?l=Inform-7',
	},
	INI: {
		color: 'text-[#d1dbe0]',
		url: 'https://github.com/trending?l=INI',
	},
	Ink: {
		color: null,
		url: 'https://github.com/trending?l=Ink',
	},
	'Inno Setup': {
		color: 'text-[#264b99]',
		url: 'https://github.com/trending?l=Inno-Setup',
	},
	Io: {
		color: 'text-[#a9188d]',
		url: 'https://github.com/trending?l=Io',
	},
	Ioke: {
		color: 'text-[#078193]',
		url: 'https://github.com/trending?l=Ioke',
	},
	Isabelle: {
		color: 'text-[#FEFE00]',
		url: 'https://github.com/trending?l=Isabelle',
	},
	'Isabelle ROOT': {
		color: 'text-[#FEFE00]',
		url: 'https://github.com/trending?l=Isabelle-ROOT',
	},
	J: {
		color: 'text-[#9EEDFF]',
		url: 'https://github.com/trending?l=J',
	},
	Janet: {
		color: 'text-[#0886a5]',
		url: 'https://github.com/trending?l=Janet',
	},
	'JAR Manifest': {
		color: 'text-[#b07219]',
		url: 'https://github.com/trending?l=JAR-Manifest',
	},
	Jasmin: {
		color: 'text-[#d03600]',
		url: 'https://github.com/trending?l=Jasmin',
	},
	Java: {
		color: 'text-[#b07219]',
		url: 'https://github.com/trending?l=Java',
	},
	'Java Properties': {
		color: 'text-[#2A6277]',
		url: 'https://github.com/trending?l=Java-Properties',
	},
	'Java Server Pages': {
		color: 'text-[#2A6277]',
		url: 'https://github.com/trending?l=Java-Server-Pages',
	},
	JavaScript: {
		color: 'text-[#f1e05a]',
		url: 'https://github.com/trending?l=JavaScript',
	},
	'JavaScript+ERB': {
		color: 'text-[#f1e05a]',
		url: 'https://github.com/trending?l=JavaScript+ERB',
	},
	JCL: {
		color: 'text-[#d90e09]',
		url: 'https://github.com/trending?l=JCL',
	},
	'Jest Snapshot': {
		color: 'text-[#15c213]',
		url: 'https://github.com/trending?l=Jest-Snapshot',
	},
	'JetBrains MPS': {
		color: 'text-[#21D789]',
		url: 'https://github.com/trending?l=JetBrains-MPS',
	},
	JFlex: {
		color: 'text-[#DBCA00]',
		url: 'https://github.com/trending?l=JFlex',
	},
	Jinja: {
		color: 'text-[#a52a22]',
		url: 'https://github.com/trending?l=Jinja',
	},
	Jison: {
		color: 'text-[#56b3cb]',
		url: 'https://github.com/trending?l=Jison',
	},
	'Jison Lex': {
		color: 'text-[#56b3cb]',
		url: 'https://github.com/trending?l=Jison-Lex',
	},
	Jolie: {
		color: 'text-[#843179]',
		url: 'https://github.com/trending?l=Jolie',
	},
	jq: {
		color: 'text-[#c7254e]',
		url: 'https://github.com/trending?l=jq',
	},
	JSON: {
		color: 'text-[#292929]',
		url: 'https://github.com/trending?l=JSON',
	},
	'JSON with Comments': {
		color: 'text-[#292929]',
		url: 'https://github.com/trending?l=JSON-with-Comments',
	},
	JSON5: {
		color: 'text-[#267CB9]',
		url: 'https://github.com/trending?l=JSON5',
	},
	JSONiq: {
		color: 'text-[#40d47e]',
		url: 'https://github.com/trending?l=JSONiq',
	},
	JSONLD: {
		color: 'text-[#0c479c]',
		url: 'https://github.com/trending?l=JSONLD',
	},
	Jsonnet: {
		color: 'text-[#0064bd]',
		url: 'https://github.com/trending?l=Jsonnet',
	},
	Julia: {
		color: 'text-[#a270ba]',
		url: 'https://github.com/trending?l=Julia',
	},
	'Jupyter Notebook': {
		color: 'text-[#DA5B0B]',
		url: 'https://github.com/trending?l=Jupyter-Notebook',
	},
	Just: {
		color: 'text-[#384d54]',
		url: 'https://github.com/trending?l=Just',
	},
	'Kaitai Struct': {
		color: 'text-[#773b37]',
		url: 'https://github.com/trending?l=Kaitai-Struct',
	},
	KakouneScript: {
		color: 'text-[#6f8042]',
		url: 'https://github.com/trending?l=KakouneScript',
	},
	KerboScript: {
		color: 'text-[#41adf0]',
		url: 'https://github.com/trending?l=KerboScript',
	},
	'KiCad Layout': {
		color: 'text-[#2f4aab]',
		url: 'https://github.com/trending?l=KiCad-Layout',
	},
	'KiCad Legacy Layout': {
		color: 'text-[#2f4aab]',
		url: 'https://github.com/trending?l=KiCad-Legacy-Layout',
	},
	'KiCad Schematic': {
		color: 'text-[#2f4aab]',
		url: 'https://github.com/trending?l=KiCad-Schematic',
	},
	Kotlin: {
		color: 'text-[#A97BFF]',
		url: 'https://github.com/trending?l=Kotlin',
	},
	KRL: {
		color: 'text-[#28430A]',
		url: 'https://github.com/trending?l=KRL',
	},
	kvlang: {
		color: 'text-[#1da6e0]',
		url: 'https://github.com/trending?l=kvlang',
	},
	LabVIEW: {
		color: 'text-[#fede06]',
		url: 'https://github.com/trending?l=LabVIEW',
	},
	Lark: {
		color: 'text-[#2980B9]',
		url: 'https://github.com/trending?l=Lark',
	},
	Lasso: {
		color: 'text-[#999999]',
		url: 'https://github.com/trending?l=Lasso',
	},
	Latte: {
		color: 'text-[#f2a542]',
		url: 'https://github.com/trending?l=Latte',
	},
	Lean: {
		color: null,
		url: 'https://github.com/trending?l=Lean',
	},
	'Lean 4': {
		color: null,
		url: 'https://github.com/trending?l=Lean-4',
	},
	Less: {
		color: 'text-[#1d365d]',
		url: 'https://github.com/trending?l=Less',
	},
	Lex: {
		color: 'text-[#DBCA00]',
		url: 'https://github.com/trending?l=Lex',
	},
	LFE: {
		color: 'text-[#4C3023]',
		url: 'https://github.com/trending?l=LFE',
	},
	LigoLANG: {
		color: 'text-[#0e74ff]',
		url: 'https://github.com/trending?l=LigoLANG',
	},
	LilyPond: {
		color: 'text-[#9ccc7c]',
		url: 'https://github.com/trending?l=LilyPond',
	},
	Limbo: {
		color: null,
		url: 'https://github.com/trending?l=Limbo',
	},
	Liquid: {
		color: 'text-[#67b8de]',
		url: 'https://github.com/trending?l=Liquid',
	},
	'Literate Agda': {
		color: 'text-[#315665]',
		url: 'https://github.com/trending?l=Literate-Agda',
	},
	'Literate CoffeeScript': {
		color: 'text-[#244776]',
		url: 'https://github.com/trending?l=Literate-CoffeeScript',
	},
	'Literate Haskell': {
		color: 'text-[#5e5086]',
		url: 'https://github.com/trending?l=Literate-Haskell',
	},
	LiveScript: {
		color: 'text-[#499886]',
		url: 'https://github.com/trending?l=LiveScript',
	},
	LLVM: {
		color: 'text-[#185619]',
		url: 'https://github.com/trending?l=LLVM',
	},
	Logos: {
		color: null,
		url: 'https://github.com/trending?l=Logos',
	},
	Logtalk: {
		color: 'text-[#295b9a]',
		url: 'https://github.com/trending?l=Logtalk',
	},
	LOLCODE: {
		color: 'text-[#cc9900]',
		url: 'https://github.com/trending?l=LOLCODE',
	},
	LookML: {
		color: 'text-[#652B81]',
		url: 'https://github.com/trending?l=LookML',
	},
	LoomScript: {
		color: null,
		url: 'https://github.com/trending?l=LoomScript',
	},
	LSL: {
		color: 'text-[#3d9970]',
		url: 'https://github.com/trending?l=LSL',
	},
	Lua: {
		color: 'text-[#000080]',
		url: 'https://github.com/trending?l=Lua',
	},
	M: {
		color: null,
		url: 'https://github.com/trending?l=M',
	},
	M4: {
		color: null,
		url: 'https://github.com/trending?l=M4',
	},
	M4Sugar: {
		color: null,
		url: 'https://github.com/trending?l=M4Sugar',
	},
	Macaulay2: {
		color: 'text-[#d8ffff]',
		url: 'https://github.com/trending?l=Macaulay2',
	},
	Makefile: {
		color: 'text-[#427819]',
		url: 'https://github.com/trending?l=Makefile',
	},
	Mako: {
		color: 'text-[#7e858d]',
		url: 'https://github.com/trending?l=Mako',
	},
	Markdown: {
		color: 'text-[#083fa1]',
		url: 'https://github.com/trending?l=Markdown',
	},
	Marko: {
		color: 'text-[#42bff2]',
		url: 'https://github.com/trending?l=Marko',
	},
	Mask: {
		color: 'text-[#f97732]',
		url: 'https://github.com/trending?l=Mask',
	},
	Mathematica: {
		color: 'text-[#dd1100]',
		url: 'https://github.com/trending?l=Mathematica',
	},
	MATLAB: {
		color: 'text-[#e16737]',
		url: 'https://github.com/trending?l=MATLAB',
	},
	Max: {
		color: 'text-[#c4a79c]',
		url: 'https://github.com/trending?l=Max',
	},
	MAXScript: {
		color: 'text-[#00a6a6]',
		url: 'https://github.com/trending?l=MAXScript',
	},
	mcfunction: {
		color: 'text-[#E22837]',
		url: 'https://github.com/trending?l=mcfunction',
	},
	MDX: {
		color: 'text-[#fcb32c]',
		url: 'https://github.com/trending?l=MDX',
	},
	Mercury: {
		color: 'text-[#ff2b2b]',
		url: 'https://github.com/trending?l=Mercury',
	},
	Mermaid: {
		color: 'text-[#ff3670]',
		url: 'https://github.com/trending?l=Mermaid',
	},
	Meson: {
		color: 'text-[#007800]',
		url: 'https://github.com/trending?l=Meson',
	},
	Metal: {
		color: 'text-[#8f14e9]',
		url: 'https://github.com/trending?l=Metal',
	},
	MiniD: {
		color: null,
		url: 'https://github.com/trending?l=MiniD',
	},
	MiniYAML: {
		color: 'text-[#ff1111]',
		url: 'https://github.com/trending?l=MiniYAML',
	},
	Mint: {
		color: 'text-[#02b046]',
		url: 'https://github.com/trending?l=Mint',
	},
	Mirah: {
		color: 'text-[#c7a938]',
		url: 'https://github.com/trending?l=Mirah',
	},
	'mIRC Script': {
		color: 'text-[#3d57c3]',
		url: 'https://github.com/trending?l=mIRC-Script',
	},
	MLIR: {
		color: 'text-[#5EC8DB]',
		url: 'https://github.com/trending?l=MLIR',
	},
	Modelica: {
		color: 'text-[#de1d31]',
		url: 'https://github.com/trending?l=Modelica',
	},
	'Modula-2': {
		color: 'text-[#10253f]',
		url: 'https://github.com/trending?l=Modula-2',
	},
	'Modula-3': {
		color: 'text-[#223388]',
		url: 'https://github.com/trending?l=Modula-3',
	},
	'Module Management System': {
		color: null,
		url: 'https://github.com/trending?l=Module-Management-System',
	},
	Monkey: {
		color: null,
		url: 'https://github.com/trending?l=Monkey',
	},
	'Monkey C': {
		color: 'text-[#8D6747]',
		url: 'https://github.com/trending?l=Monkey-C',
	},
	Moocode: {
		color: null,
		url: 'https://github.com/trending?l=Moocode',
	},
	MoonScript: {
		color: 'text-[#ff4585]',
		url: 'https://github.com/trending?l=MoonScript',
	},
	Motoko: {
		color: 'text-[#fbb03b]',
		url: 'https://github.com/trending?l=Motoko',
	},
	'Motorola 68K Assembly': {
		color: 'text-[#005daa]',
		url: 'https://github.com/trending?l=Motorola-68K-Assembly',
	},
	Move: {
		color: 'text-[#4a137a]',
		url: 'https://github.com/trending?l=Move',
	},
	MQL4: {
		color: 'text-[#62A8D6]',
		url: 'https://github.com/trending?l=MQL4',
	},
	MQL5: {
		color: 'text-[#4A76B8]',
		url: 'https://github.com/trending?l=MQL5',
	},
	MTML: {
		color: 'text-[#b7e1f4]',
		url: 'https://github.com/trending?l=MTML',
	},
	MUF: {
		color: null,
		url: 'https://github.com/trending?l=MUF',
	},
	mupad: {
		color: 'text-[#244963]',
		url: 'https://github.com/trending?l=mupad',
	},
	Mustache: {
		color: 'text-[#724b3b]',
		url: 'https://github.com/trending?l=Mustache',
	},
	Myghty: {
		color: null,
		url: 'https://github.com/trending?l=Myghty',
	},
	nanorc: {
		color: 'text-[#2d004d]',
		url: 'https://github.com/trending?l=nanorc',
	},
	Nasal: {
		color: 'text-[#1d2c4e]',
		url: 'https://github.com/trending?l=Nasal',
	},
	NASL: {
		color: null,
		url: 'https://github.com/trending?l=NASL',
	},
	NCL: {
		color: 'text-[#28431f]',
		url: 'https://github.com/trending?l=NCL',
	},
	Nearley: {
		color: 'text-[#990000]',
		url: 'https://github.com/trending?l=Nearley',
	},
	Nemerle: {
		color: 'text-[#3d3c6e]',
		url: 'https://github.com/trending?l=Nemerle',
	},
	nesC: {
		color: 'text-[#94B0C7]',
		url: 'https://github.com/trending?l=nesC',
	},
	NetLinx: {
		color: 'text-[#0aa0ff]',
		url: 'https://github.com/trending?l=NetLinx',
	},
	'NetLinx+ERB': {
		color: 'text-[#747faa]',
		url: 'https://github.com/trending?l=NetLinx+ERB',
	},
	NetLogo: {
		color: 'text-[#ff6375]',
		url: 'https://github.com/trending?l=NetLogo',
	},
	NewLisp: {
		color: 'text-[#87AED7]',
		url: 'https://github.com/trending?l=NewLisp',
	},
	Nextflow: {
		color: 'text-[#3ac486]',
		url: 'https://github.com/trending?l=Nextflow',
	},
	Nginx: {
		color: 'text-[#009639]',
		url: 'https://github.com/trending?l=Nginx',
	},
	Nim: {
		color: 'text-[#ffc200]',
		url: 'https://github.com/trending?l=Nim',
	},
	Nit: {
		color: 'text-[#009917]',
		url: 'https://github.com/trending?l=Nit',
	},
	Nix: {
		color: 'text-[#7e7eff]',
		url: 'https://github.com/trending?l=Nix',
	},
	'NPM Config': {
		color: 'text-[#cb3837]',
		url: 'https://github.com/trending?l=NPM-Config',
	},
	NSIS: {
		color: null,
		url: 'https://github.com/trending?l=NSIS',
	},
	Nu: {
		color: 'text-[#c9df40]',
		url: 'https://github.com/trending?l=Nu',
	},
	NumPy: {
		color: 'text-[#9C8AF9]',
		url: 'https://github.com/trending?l=NumPy',
	},
	Nunjucks: {
		color: 'text-[#3d8137]',
		url: 'https://github.com/trending?l=Nunjucks',
	},
	Nushell: {
		color: 'text-[#4E9906]',
		url: 'https://github.com/trending?l=Nushell',
	},
	NWScript: {
		color: 'text-[#111522]',
		url: 'https://github.com/trending?l=NWScript',
	},
	'OASv2-json': {
		color: 'text-[#85ea2d]',
		url: 'https://github.com/trending?l=OASv2-json',
	},
	'OASv2-yaml': {
		color: 'text-[#85ea2d]',
		url: 'https://github.com/trending?l=OASv2-yaml',
	},
	'OASv3-json': {
		color: 'text-[#85ea2d]',
		url: 'https://github.com/trending?l=OASv3-json',
	},
	'OASv3-yaml': {
		color: 'text-[#85ea2d]',
		url: 'https://github.com/trending?l=OASv3-yaml',
	},
	'Objective-C': {
		color: 'text-[#438eff]',
		url: 'https://github.com/trending?l=Objective-C',
	},
	'Objective-C++': {
		color: 'text-[#6866fb]',
		url: 'https://github.com/trending?l=Objective-C++',
	},
	'Objective-J': {
		color: 'text-[#ff0c5a]',
		url: 'https://github.com/trending?l=Objective-J',
	},
	ObjectScript: {
		color: 'text-[#424893]',
		url: 'https://github.com/trending?l=ObjectScript',
	},
	OCaml: {
		color: 'text-[#ef7a08]',
		url: 'https://github.com/trending?l=OCaml',
	},
	Odin: {
		color: 'text-[#60AFFE]',
		url: 'https://github.com/trending?l=Odin',
	},
	Omgrofl: {
		color: 'text-[#cabbff]',
		url: 'https://github.com/trending?l=Omgrofl',
	},
	ooc: {
		color: 'text-[#b0b77e]',
		url: 'https://github.com/trending?l=ooc',
	},
	Opa: {
		color: null,
		url: 'https://github.com/trending?l=Opa',
	},
	Opal: {
		color: 'text-[#f7ede0]',
		url: 'https://github.com/trending?l=Opal',
	},
	'Open Policy Agent': {
		color: 'text-[#7d9199]',
		url: 'https://github.com/trending?l=Open-Policy-Agent',
	},
	'OpenAPI Specification v2': {
		color: 'text-[#85ea2d]',
		url: 'https://github.com/trending?l=OpenAPI-Specification-v2',
	},
	'OpenAPI Specification v3': {
		color: 'text-[#85ea2d]',
		url: 'https://github.com/trending?l=OpenAPI-Specification-v3',
	},
	OpenCL: {
		color: 'text-[#ed2e2d]',
		url: 'https://github.com/trending?l=OpenCL',
	},
	'OpenEdge ABL': {
		color: 'text-[#5ce600]',
		url: 'https://github.com/trending?l=OpenEdge-ABL',
	},
	OpenQASM: {
		color: 'text-[#AA70FF]',
		url: 'https://github.com/trending?l=OpenQASM',
	},
	'OpenRC runscript': {
		color: null,
		url: 'https://github.com/trending?l=OpenRC-runscript',
	},
	OpenSCAD: {
		color: 'text-[#e5cd45]',
		url: 'https://github.com/trending?l=OpenSCAD',
	},
	'Option List': {
		color: 'text-[#476732]',
		url: 'https://github.com/trending?l=Option-List',
	},
	Org: {
		color: 'text-[#77aa99]',
		url: 'https://github.com/trending?l=Org',
	},
	Ox: {
		color: null,
		url: 'https://github.com/trending?l=Ox',
	},
	Oxygene: {
		color: 'text-[#cdd0e3]',
		url: 'https://github.com/trending?l=Oxygene',
	},
	Oz: {
		color: 'text-[#fab738]',
		url: 'https://github.com/trending?l=Oz',
	},
	P4: {
		color: 'text-[#7055b5]',
		url: 'https://github.com/trending?l=P4',
	},
	Pact: {
		color: 'text-[#F7A8B8]',
		url: 'https://github.com/trending?l=Pact',
	},
	Pan: {
		color: 'text-[#cc0000]',
		url: 'https://github.com/trending?l=Pan',
	},
	Papyrus: {
		color: 'text-[#6600cc]',
		url: 'https://github.com/trending?l=Papyrus',
	},
	Parrot: {
		color: 'text-[#f3ca0a]',
		url: 'https://github.com/trending?l=Parrot',
	},
	'Parrot Assembly': {
		color: null,
		url: 'https://github.com/trending?l=Parrot-Assembly',
	},
	'Parrot Internal Representation': {
		color: null,
		url: 'https://github.com/trending?l=Parrot-Internal-Representation',
	},
	Pascal: {
		color: 'text-[#E3F171]',
		url: 'https://github.com/trending?l=Pascal',
	},
	Pawn: {
		color: 'text-[#dbb284]',
		url: 'https://github.com/trending?l=Pawn',
	},
	PDDL: {
		color: 'text-[#0d00ff]',
		url: 'https://github.com/trending?l=PDDL',
	},
	'PEG.js': {
		color: 'text-[#234d6b]',
		url: 'https://github.com/trending?l=PEG.js',
	},
	Pep8: {
		color: 'text-[#C76F5B]',
		url: 'https://github.com/trending?l=Pep8',
	},
	Perl: {
		color: 'text-[#0298c3]',
		url: 'https://github.com/trending?l=Perl',
	},
	PHP: {
		color: 'text-[#4F5D95]',
		url: 'https://github.com/trending?l=PHP',
	},
	PicoLisp: {
		color: 'text-[#6067af]',
		url: 'https://github.com/trending?l=PicoLisp',
	},
	PigLatin: {
		color: 'text-[#fcd7de]',
		url: 'https://github.com/trending?l=PigLatin',
	},
	Pike: {
		color: 'text-[#005390]',
		url: 'https://github.com/trending?l=Pike',
	},
	PlantUML: {
		color: 'text-[#fbbd16]',
		url: 'https://github.com/trending?l=PlantUML',
	},
	PLpgSQL: {
		color: 'text-[#336790]',
		url: 'https://github.com/trending?l=PLpgSQL',
	},
	PLSQL: {
		color: 'text-[#dad8d8]',
		url: 'https://github.com/trending?l=PLSQL',
	},
	PogoScript: {
		color: 'text-[#d80074]',
		url: 'https://github.com/trending?l=PogoScript',
	},
	Polar: {
		color: 'text-[#ae81ff]',
		url: 'https://github.com/trending?l=Polar',
	},
	Pony: {
		color: null,
		url: 'https://github.com/trending?l=Pony',
	},
	Portugol: {
		color: 'text-[#f8bd00]',
		url: 'https://github.com/trending?l=Portugol',
	},
	PostCSS: {
		color: 'text-[#dc3a0c]',
		url: 'https://github.com/trending?l=PostCSS',
	},
	PostScript: {
		color: 'text-[#da291c]',
		url: 'https://github.com/trending?l=PostScript',
	},
	'POV-Ray SDL': {
		color: 'text-[#6bac65]',
		url: 'https://github.com/trending?l=POV-Ray-SDL',
	},
	PowerBuilder: {
		color: 'text-[#8f0f8d]',
		url: 'https://github.com/trending?l=PowerBuilder',
	},
	PowerShell: {
		color: 'text-[#012456]',
		url: 'https://github.com/trending?l=PowerShell',
	},
	Praat: {
		color: 'text-[#c8506d]',
		url: 'https://github.com/trending?l=Praat',
	},
	Prisma: {
		color: 'text-[#0c344b]',
		url: 'https://github.com/trending?l=Prisma',
	},
	Processing: {
		color: 'text-[#0096D8]',
		url: 'https://github.com/trending?l=Processing',
	},
	Procfile: {
		color: 'text-[#3B2F63]',
		url: 'https://github.com/trending?l=Procfile',
	},
	Prolog: {
		color: 'text-[#74283c]',
		url: 'https://github.com/trending?l=Prolog',
	},
	Promela: {
		color: 'text-[#de0000]',
		url: 'https://github.com/trending?l=Promela',
	},
	'Propeller Spin': {
		color: 'text-[#7fa2a7]',
		url: 'https://github.com/trending?l=Propeller-Spin',
	},
	Pug: {
		color: 'text-[#a86454]',
		url: 'https://github.com/trending?l=Pug',
	},
	Puppet: {
		color: 'text-[#302B6D]',
		url: 'https://github.com/trending?l=Puppet',
	},
	PureBasic: {
		color: 'text-[#5a6986]',
		url: 'https://github.com/trending?l=PureBasic',
	},
	PureScript: {
		color: 'text-[#1D222D]',
		url: 'https://github.com/trending?l=PureScript',
	},
	Pyret: {
		color: 'text-[#ee1e10]',
		url: 'https://github.com/trending?l=Pyret',
	},
	Python: {
		color: 'text-[#3572A5]',
		url: 'https://github.com/trending?l=Python',
	},
	'Python console': {
		color: 'text-[#3572A5]',
		url: 'https://github.com/trending?l=Python-console',
	},
	'Python traceback': {
		color: 'text-[#3572A5]',
		url: 'https://github.com/trending?l=Python-traceback',
	},
	q: {
		color: 'text-[#0040cd]',
		url: 'https://github.com/trending?l=q',
	},
	'Q#': {
		color: 'text-[#fed659]',
		url: 'https://github.com/trending?l=Qsharp',
	},
	QMake: {
		color: null,
		url: 'https://github.com/trending?l=QMake',
	},
	QML: {
		color: 'text-[#44a51c]',
		url: 'https://github.com/trending?l=QML',
	},
	'Qt Script': {
		color: 'text-[#00b841]',
		url: 'https://github.com/trending?l=Qt-Script',
	},
	Quake: {
		color: 'text-[#882233]',
		url: 'https://github.com/trending?l=Quake',
	},
	R: {
		color: 'text-[#198CE7]',
		url: 'https://github.com/trending?l=R',
	},
	Racket: {
		color: 'text-[#3c5caa]',
		url: 'https://github.com/trending?l=Racket',
	},
	Ragel: {
		color: 'text-[#9d5200]',
		url: 'https://github.com/trending?l=Ragel',
	},
	Raku: {
		color: 'text-[#0000fb]',
		url: 'https://github.com/trending?l=Raku',
	},
	RAML: {
		color: 'text-[#77d9fb]',
		url: 'https://github.com/trending?l=RAML',
	},
	Rascal: {
		color: 'text-[#fffaa0]',
		url: 'https://github.com/trending?l=Rascal',
	},
	RBS: {
		color: 'text-[#701516]',
		url: 'https://github.com/trending?l=RBS',
	},
	RDoc: {
		color: 'text-[#701516]',
		url: 'https://github.com/trending?l=RDoc',
	},
	REALbasic: {
		color: null,
		url: 'https://github.com/trending?l=REALbasic',
	},
	Reason: {
		color: 'text-[#ff5847]',
		url: 'https://github.com/trending?l=Reason',
	},
	ReasonLIGO: {
		color: 'text-[#ff5847]',
		url: 'https://github.com/trending?l=ReasonLIGO',
	},
	Rebol: {
		color: 'text-[#358a5b]',
		url: 'https://github.com/trending?l=Rebol',
	},
	'Record Jar': {
		color: 'text-[#0673ba]',
		url: 'https://github.com/trending?l=Record-Jar',
	},
	Red: {
		color: 'text-[#f50000]',
		url: 'https://github.com/trending?l=Red',
	},
	Redcode: {
		color: null,
		url: 'https://github.com/trending?l=Redcode',
	},
	'Regular Expression': {
		color: 'text-[#009a00]',
		url: 'https://github.com/trending?l=Regular-Expression',
	},
	"Ren'Py": {
		color: 'text-[#ff7f7f]',
		url: "https://github.com/trending?l=Ren'Py",
	},
	RenderScript: {
		color: null,
		url: 'https://github.com/trending?l=RenderScript',
	},
	ReScript: {
		color: 'text-[#ed5051]',
		url: 'https://github.com/trending?l=ReScript',
	},
	reStructuredText: {
		color: 'text-[#141414]',
		url: 'https://github.com/trending?l=reStructuredText',
	},
	REXX: {
		color: 'text-[#d90e09]',
		url: 'https://github.com/trending?l=REXX',
	},
	Rez: {
		color: 'text-[#FFDAB3]',
		url: 'https://github.com/trending?l=Rez',
	},
	Ring: {
		color: 'text-[#2D54CB]',
		url: 'https://github.com/trending?l=Ring',
	},
	Riot: {
		color: 'text-[#A71E49]',
		url: 'https://github.com/trending?l=Riot',
	},
	RMarkdown: {
		color: 'text-[#198ce7]',
		url: 'https://github.com/trending?l=RMarkdown',
	},
	RobotFramework: {
		color: 'text-[#00c0b5]',
		url: 'https://github.com/trending?l=RobotFramework',
	},
	Roff: {
		color: 'text-[#ecdebe]',
		url: 'https://github.com/trending?l=Roff',
	},
	'Roff Manpage': {
		color: 'text-[#ecdebe]',
		url: 'https://github.com/trending?l=Roff-Manpage',
	},
	Rouge: {
		color: 'text-[#cc0088]',
		url: 'https://github.com/trending?l=Rouge',
	},
	'RouterOS Script': {
		color: 'text-[#DE3941]',
		url: 'https://github.com/trending?l=RouterOS-Script',
	},
	RPC: {
		color: null,
		url: 'https://github.com/trending?l=RPC',
	},
	RPGLE: {
		color: 'text-[#2BDE21]',
		url: 'https://github.com/trending?l=RPGLE',
	},
	Ruby: {
		color: 'text-[#701516]',
		url: 'https://github.com/trending?l=Ruby',
	},
	RUNOFF: {
		color: 'text-[#665a4e]',
		url: 'https://github.com/trending?l=RUNOFF',
	},
	Rust: {
		color: 'text-[#dea584]',
		url: 'https://github.com/trending?l=Rust',
	},
	Sage: {
		color: null,
		url: 'https://github.com/trending?l=Sage',
	},
	SaltStack: {
		color: 'text-[#646464]',
		url: 'https://github.com/trending?l=SaltStack',
	},
	SAS: {
		color: 'text-[#B34936]',
		url: 'https://github.com/trending?l=SAS',
	},
	Sass: {
		color: 'text-[#a53b70]',
		url: 'https://github.com/trending?l=Sass',
	},
	Scala: {
		color: 'text-[#c22d40]',
		url: 'https://github.com/trending?l=Scala',
	},
	Scaml: {
		color: 'text-[#bd181a]',
		url: 'https://github.com/trending?l=Scaml',
	},
	Scenic: {
		color: 'text-[#fdc700]',
		url: 'https://github.com/trending?l=Scenic',
	},
	Scheme: {
		color: 'text-[#1e4aec]',
		url: 'https://github.com/trending?l=Scheme',
	},
	Scilab: {
		color: 'text-[#ca0f21]',
		url: 'https://github.com/trending?l=Scilab',
	},
	SCSS: {
		color: 'text-[#c6538c]',
		url: 'https://github.com/trending?l=SCSS',
	},
	sed: {
		color: 'text-[#64b970]',
		url: 'https://github.com/trending?l=sed',
	},
	Self: {
		color: 'text-[#0579aa]',
		url: 'https://github.com/trending?l=Self',
	},
	ShaderLab: {
		color: 'text-[#222c37]',
		url: 'https://github.com/trending?l=ShaderLab',
	},
	Shell: {
		color: 'text-[#89e051]',
		url: 'https://github.com/trending?l=Shell',
	},
	'ShellCheck Config': {
		color: 'text-[#cecfcb]',
		url: 'https://github.com/trending?l=ShellCheck-Config',
	},
	ShellSession: {
		color: null,
		url: 'https://github.com/trending?l=ShellSession',
	},
	Shen: {
		color: 'text-[#120F14]',
		url: 'https://github.com/trending?l=Shen',
	},
	Sieve: {
		color: null,
		url: 'https://github.com/trending?l=Sieve',
	},
	'Simple File Verification': {
		color: 'text-[#C9BFED]',
		url: 'https://github.com/trending?l=Simple-File-Verification',
	},
	Singularity: {
		color: 'text-[#64E6AD]',
		url: 'https://github.com/trending?l=Singularity',
	},
	Slash: {
		color: 'text-[#007eff]',
		url: 'https://github.com/trending?l=Slash',
	},
	Slice: {
		color: 'text-[#003fa2]',
		url: 'https://github.com/trending?l=Slice',
	},
	Slim: {
		color: 'text-[#2b2b2b]',
		url: 'https://github.com/trending?l=Slim',
	},
	Smali: {
		color: null,
		url: 'https://github.com/trending?l=Smali',
	},
	Smalltalk: {
		color: 'text-[#596706]',
		url: 'https://github.com/trending?l=Smalltalk',
	},
	Smarty: {
		color: 'text-[#f0c040]',
		url: 'https://github.com/trending?l=Smarty',
	},
	Smithy: {
		color: 'text-[#c44536]',
		url: 'https://github.com/trending?l=Smithy',
	},
	SmPL: {
		color: 'text-[#c94949]',
		url: 'https://github.com/trending?l=SmPL',
	},
	SMT: {
		color: null,
		url: 'https://github.com/trending?l=SMT',
	},
	Snakemake: {
		color: 'text-[#419179]',
		url: 'https://github.com/trending?l=Snakemake',
	},
	Solidity: {
		color: 'text-[#AA6746]',
		url: 'https://github.com/trending?l=Solidity',
	},
	SourcePawn: {
		color: 'text-[#f69e1d]',
		url: 'https://github.com/trending?l=SourcePawn',
	},
	SPARQL: {
		color: 'text-[#0C4597]',
		url: 'https://github.com/trending?l=SPARQL',
	},
	SQF: {
		color: 'text-[#3F3F3F]',
		url: 'https://github.com/trending?l=SQF',
	},
	SQL: {
		color: 'text-[#e38c00]',
		url: 'https://github.com/trending?l=SQL',
	},
	SQLPL: {
		color: 'text-[#e38c00]',
		url: 'https://github.com/trending?l=SQLPL',
	},
	Squirrel: {
		color: 'text-[#800000]',
		url: 'https://github.com/trending?l=Squirrel',
	},
	'SRecode Template': {
		color: 'text-[#348a34]',
		url: 'https://github.com/trending?l=SRecode-Template',
	},
	Stan: {
		color: 'text-[#b2011d]',
		url: 'https://github.com/trending?l=Stan',
	},
	'Standard ML': {
		color: 'text-[#dc566d]',
		url: 'https://github.com/trending?l=Standard-ML',
	},
	Starlark: {
		color: 'text-[#76d275]',
		url: 'https://github.com/trending?l=Starlark',
	},
	Stata: {
		color: 'text-[#1a5f91]',
		url: 'https://github.com/trending?l=Stata',
	},
	STL: {
		color: 'text-[#373b5e]',
		url: 'https://github.com/trending?l=STL',
	},
	StringTemplate: {
		color: 'text-[#3fb34f]',
		url: 'https://github.com/trending?l=StringTemplate',
	},
	Stylus: {
		color: 'text-[#ff6347]',
		url: 'https://github.com/trending?l=Stylus',
	},
	'SubRip Text': {
		color: 'text-[#9e0101]',
		url: 'https://github.com/trending?l=SubRip-Text',
	},
	SugarSS: {
		color: 'text-[#2fcc9f]',
		url: 'https://github.com/trending?l=SugarSS',
	},
	SuperCollider: {
		color: 'text-[#46390b]',
		url: 'https://github.com/trending?l=SuperCollider',
	},
	Svelte: {
		color: 'text-[#ff3e00]',
		url: 'https://github.com/trending?l=Svelte',
	},
	SVG: {
		color: 'text-[#ff9900]',
		url: 'https://github.com/trending?l=SVG',
	},
	Sway: {
		color: 'text-[#00F58C]',
		url: 'https://github.com/trending?l=Sway',
	},
	Sweave: {
		color: 'text-[#198ce7]',
		url: 'https://github.com/trending?l=Sweave',
	},
	Swift: {
		color: 'text-[#F05138]',
		url: 'https://github.com/trending?l=Swift',
	},
	SWIG: {
		color: null,
		url: 'https://github.com/trending?l=SWIG',
	},
	SystemVerilog: {
		color: 'text-[#DAE1C2]',
		url: 'https://github.com/trending?l=SystemVerilog',
	},
	Talon: {
		color: 'text-[#333333]',
		url: 'https://github.com/trending?l=Talon',
	},
	Tcl: {
		color: 'text-[#e4cc98]',
		url: 'https://github.com/trending?l=Tcl',
	},
	Tcsh: {
		color: null,
		url: 'https://github.com/trending?l=Tcsh',
	},
	Terra: {
		color: 'text-[#00004c]',
		url: 'https://github.com/trending?l=Terra',
	},
	'Terraform Template': {
		color: 'text-[#7b42bb]',
		url: 'https://github.com/trending?l=Terraform-Template',
	},
	TeX: {
		color: 'text-[#3D6117]',
		url: 'https://github.com/trending?l=TeX',
	},
	Textile: {
		color: 'text-[#ffe7ac]',
		url: 'https://github.com/trending?l=Textile',
	},
	'TextMate Properties': {
		color: 'text-[#df66e4]',
		url: 'https://github.com/trending?l=TextMate-Properties',
	},
	Thrift: {
		color: 'text-[#D12127]',
		url: 'https://github.com/trending?l=Thrift',
	},
	'TI Program': {
		color: 'text-[#A0AA87]',
		url: 'https://github.com/trending?l=TI-Program',
	},
	'TL-Verilog': {
		color: 'text-[#C40023]',
		url: 'https://github.com/trending?l=TL-Verilog',
	},
	TLA: {
		color: 'text-[#4b0079]',
		url: 'https://github.com/trending?l=TLA',
	},
	Toit: {
		color: 'text-[#c2c9fb]',
		url: 'https://github.com/trending?l=Toit',
	},
	TOML: {
		color: 'text-[#9c4221]',
		url: 'https://github.com/trending?l=TOML',
	},
	TSQL: {
		color: 'text-[#e38c00]',
		url: 'https://github.com/trending?l=TSQL',
	},
	TSV: {
		color: 'text-[#237346]',
		url: 'https://github.com/trending?l=TSV',
	},
	TSX: {
		color: 'text-[#3178c6]',
		url: 'https://github.com/trending?l=TSX',
	},
	Turing: {
		color: 'text-[#cf142b]',
		url: 'https://github.com/trending?l=Turing',
	},
	Twig: {
		color: 'text-[#c1d026]',
		url: 'https://github.com/trending?l=Twig',
	},
	TXL: {
		color: 'text-[#0178b8]',
		url: 'https://github.com/trending?l=TXL',
	},
	TypeScript: {
		color: 'text-[#3178c6]',
		url: 'https://github.com/trending?l=TypeScript',
	},
	Typst: {
		color: 'text-[#239dad]',
		url: 'https://github.com/trending?l=Typst',
	},
	'Unified Parallel C': {
		color: 'text-[#4e3617]',
		url: 'https://github.com/trending?l=Unified-Parallel-C',
	},
	'Unity3D Asset': {
		color: 'text-[#222c37]',
		url: 'https://github.com/trending?l=Unity3D-Asset',
	},
	'Unix Assembly': {
		color: null,
		url: 'https://github.com/trending?l=Unix-Assembly',
	},
	Uno: {
		color: 'text-[#9933cc]',
		url: 'https://github.com/trending?l=Uno',
	},
	UnrealScript: {
		color: 'text-[#a54c4d]',
		url: 'https://github.com/trending?l=UnrealScript',
	},
	UrWeb: {
		color: 'text-[#ccccee]',
		url: 'https://github.com/trending?l=UrWeb',
	},
	V: {
		color: 'text-[#4f87c4]',
		url: 'https://github.com/trending?l=V',
	},
	Vala: {
		color: 'text-[#a56de2]',
		url: 'https://github.com/trending?l=Vala',
	},
	'Valve Data Format': {
		color: 'text-[#f26025]',
		url: 'https://github.com/trending?l=Valve-Data-Format',
	},
	VBA: {
		color: 'text-[#867db1]',
		url: 'https://github.com/trending?l=VBA',
	},
	VBScript: {
		color: 'text-[#15dcdc]',
		url: 'https://github.com/trending?l=VBScript',
	},
	VCL: {
		color: 'text-[#148AA8]',
		url: 'https://github.com/trending?l=VCL',
	},
	'Velocity Template Language': {
		color: 'text-[#507cff]',
		url: 'https://github.com/trending?l=Velocity-Template-Language',
	},
	Verilog: {
		color: 'text-[#b2b7f8]',
		url: 'https://github.com/trending?l=Verilog',
	},
	VHDL: {
		color: 'text-[#adb2cb]',
		url: 'https://github.com/trending?l=VHDL',
	},
	'Vim Help File': {
		color: 'text-[#199f4b]',
		url: 'https://github.com/trending?l=Vim-Help-File',
	},
	'Vim Script': {
		color: 'text-[#199f4b]',
		url: 'https://github.com/trending?l=Vim-Script',
	},
	'Vim Snippet': {
		color: 'text-[#199f4b]',
		url: 'https://github.com/trending?l=Vim-Snippet',
	},
	'Visual Basic .NET': {
		color: 'text-[#945db7]',
		url: 'https://github.com/trending?l=Visual-Basic-.NET',
	},
	'Visual Basic 6.0': {
		color: 'text-[#2c6353]',
		url: 'https://github.com/trending?l=Visual-Basic-6.0',
	},
	Volt: {
		color: 'text-[#1F1F1F]',
		url: 'https://github.com/trending?l=Volt',
	},
	Vue: {
		color: 'text-[#41b883]',
		url: 'https://github.com/trending?l=Vue',
	},
	Vyper: {
		color: 'text-[#2980b9]',
		url: 'https://github.com/trending?l=Vyper',
	},
	WDL: {
		color: 'text-[#42f1f4]',
		url: 'https://github.com/trending?l=WDL',
	},
	'Web Ontology Language': {
		color: 'text-[#5b70bd]',
		url: 'https://github.com/trending?l=Web-Ontology-Language',
	},
	WebAssembly: {
		color: 'text-[#04133b]',
		url: 'https://github.com/trending?l=WebAssembly',
	},
	'WebAssembly Interface Type': {
		color: 'text-[#6250e7]',
		url: 'https://github.com/trending?l=WebAssembly-Interface-Type',
	},
	WebIDL: {
		color: null,
		url: 'https://github.com/trending?l=WebIDL',
	},
	WGSL: {
		color: 'text-[#1a5e9a]',
		url: 'https://github.com/trending?l=WGSL',
	},
	Whiley: {
		color: 'text-[#d5c397]',
		url: 'https://github.com/trending?l=Whiley',
	},
	Wikitext: {
		color: 'text-[#fc5757]',
		url: 'https://github.com/trending?l=Wikitext',
	},
	'Windows Registry Entries': {
		color: 'text-[#52d5ff]',
		url: 'https://github.com/trending?l=Windows-Registry-Entries',
	},
	wisp: {
		color: 'text-[#7582D1]',
		url: 'https://github.com/trending?l=wisp',
	},
	'Witcher Script': {
		color: 'text-[#ff0000]',
		url: 'https://github.com/trending?l=Witcher-Script',
	},
	Wollok: {
		color: 'text-[#a23738]',
		url: 'https://github.com/trending?l=Wollok',
	},
	'World of Warcraft Addon Data': {
		color: 'text-[#f7e43f]',
		url: 'https://github.com/trending?l=World-of-Warcraft-Addon-Data',
	},
	Wren: {
		color: 'text-[#383838]',
		url: 'https://github.com/trending?l=Wren',
	},
	X10: {
		color: 'text-[#4B6BEF]',
		url: 'https://github.com/trending?l=X10',
	},
	xBase: {
		color: 'text-[#403a40]',
		url: 'https://github.com/trending?l=xBase',
	},
	XC: {
		color: 'text-[#99DA07]',
		url: 'https://github.com/trending?l=XC',
	},
	XML: {
		color: 'text-[#0060ac]',
		url: 'https://github.com/trending?l=XML',
	},
	'XML Property List': {
		color: 'text-[#0060ac]',
		url: 'https://github.com/trending?l=XML-Property-List',
	},
	Xojo: {
		color: 'text-[#81bd41]',
		url: 'https://github.com/trending?l=Xojo',
	},
	Xonsh: {
		color: 'text-[#285EEF]',
		url: 'https://github.com/trending?l=Xonsh',
	},
	XProc: {
		color: null,
		url: 'https://github.com/trending?l=XProc',
	},
	XQuery: {
		color: 'text-[#5232e7]',
		url: 'https://github.com/trending?l=XQuery',
	},
	XS: {
		color: null,
		url: 'https://github.com/trending?l=XS',
	},
	XSLT: {
		color: 'text-[#EB8CEB]',
		url: 'https://github.com/trending?l=XSLT',
	},
	Xtend: {
		color: 'text-[#24255d]',
		url: 'https://github.com/trending?l=Xtend',
	},
	Yacc: {
		color: 'text-[#4B6C4B]',
		url: 'https://github.com/trending?l=Yacc',
	},
	YAML: {
		color: 'text-[#cb171e]',
		url: 'https://github.com/trending?l=YAML',
	},
	YARA: {
		color: 'text-[#220000]',
		url: 'https://github.com/trending?l=YARA',
	},
	YASnippet: {
		color: 'text-[#32AB90]',
		url: 'https://github.com/trending?l=YASnippet',
	},
	Yul: {
		color: 'text-[#794932]',
		url: 'https://github.com/trending?l=Yul',
	},
	ZAP: {
		color: 'text-[#0d665e]',
		url: 'https://github.com/trending?l=ZAP',
	},
	Zeek: {
		color: null,
		url: 'https://github.com/trending?l=Zeek',
	},
	ZenScript: {
		color: 'text-[#00BCD1]',
		url: 'https://github.com/trending?l=ZenScript',
	},
	Zephir: {
		color: 'text-[#118f9e]',
		url: 'https://github.com/trending?l=Zephir',
	},
	Zig: {
		color: 'text-[#ec915c]',
		url: 'https://github.com/trending?l=Zig',
	},
	ZIL: {
		color: 'text-[#dc75e5]',
		url: 'https://github.com/trending?l=ZIL',
	},
	Zimpl: {
		color: 'text-[#d67711]',
		url: 'https://github.com/trending?l=Zimpl',
	},
};
