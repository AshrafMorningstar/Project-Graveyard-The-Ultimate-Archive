import React, { useState } from 'react';
import { Mail as MailIcon, Star, Trash, Send, Search, Edit3, Inbox, Archive } from 'lucide-react';

const EMAILS = [
  { id: 1, from: "GitHub", subject: "[GitHub] Security alert for your repository", time: "10:23 AM", body: "We noticed a new login to your account..." },
  { id: 2, from: "Vercel", subject: "Deployment Successful", time: "Yesterday", body: "ashraf-os has been successfully deployed to production." },
  { id: 3, from: "Dribbble", subject: "Top designs of the week", time: "Yesterday", body: "Check out the latest trending designs..." },
  { id: 4, from: "Product Hunt", subject: "AshrafOS is trending!", time: "2 days ago", body: "Congratulations! Your product is #1 today." }
];

export const Mail: React.FC = () => {
  const [selectedEmail, setSelectedEmail] = useState<number | null>(null);

  return (
    <div className="flex h-full bg-[#1e1e24] text-gray-200">
      {/* Sidebar */}
      <div className="w-16 sm:w-60 bg-[#151518] border-r border-white/5 flex flex-col">
        <div className="p-4 flex items-center justify-center sm:justify-start gap-3 border-b border-white/5">
            <Edit3 size={18} className="text-blue-500" />
            <span className="hidden sm:block font-bold">Compose</span>
        </div>
        <div className="p-2 space-y-1">
            <div className="flex items-center gap-3 px-3 py-2 bg-blue-600/20 text-blue-400 rounded-lg cursor-pointer">
                <Inbox size={18} />
                <span className="hidden sm:block font-medium">Inbox</span>
                <span className="hidden sm:block ml-auto text-xs opacity-70">4</span>
            </div>
            <div className="flex items-center gap-3 px-3 py-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg cursor-pointer">
                <Send size={18} />
                <span className="hidden sm:block font-medium">Sent</span>
            </div>
            <div className="flex items-center gap-3 px-3 py-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg cursor-pointer">
                <Archive size={18} />
                <span className="hidden sm:block font-medium">Archive</span>
            </div>
            <div className="flex items-center gap-3 px-3 py-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-lg cursor-pointer">
                <Trash size={18} />
                <span className="hidden sm:block font-medium">Trash</span>
            </div>
        </div>
      </div>

      {/* Email List */}
      <div className={`${selectedEmail ? 'hidden md:block' : 'block'} w-full md:w-80 border-r border-white/5 bg-[#1a1a1e] overflow-y-auto`}>
        <div className="p-4 border-b border-white/5 sticky top-0 bg-[#1a1a1e] z-10">
            <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input type="text" placeholder="Search" className="w-full bg-[#0f0f12] rounded-lg pl-9 pr-4 py-1.5 text-sm outline-none focus:ring-1 focus:ring-blue-500/50" />
            </div>
        </div>
        {EMAILS.map(email => (
            <div 
                key={email.id}
                onClick={() => setSelectedEmail(email.id)}
                className={`p-4 border-b border-white/5 cursor-pointer transition-colors hover:bg-white/5 ${selectedEmail === email.id ? 'bg-blue-600/10 border-l-2 border-l-blue-500' : ''}`}
            >
                <div className="flex justify-between items-start mb-1">
                    <span className={`font-bold text-sm ${selectedEmail === email.id ? 'text-blue-400' : 'text-white'}`}>{email.from}</span>
                    <span className="text-xs text-gray-500">{email.time}</span>
                </div>
                <div className="text-sm font-medium text-gray-300 mb-1 truncate">{email.subject}</div>
                <div className="text-xs text-gray-500 line-clamp-2">{email.body}</div>
            </div>
        ))}
      </div>

      {/* Reading Pane */}
      <div className={`${selectedEmail ? 'block' : 'hidden md:block'} flex-1 bg-[#1e1e24] flex flex-col`}>
        {selectedEmail ? (
            <>
                <div className="p-6 border-b border-white/5 flex justify-between items-start">
                    <div>
                        <h2 className="text-xl font-bold text-white mb-2">{EMAILS.find(e => e.id === selectedEmail)?.subject}</h2>
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-xs font-bold">
                                {EMAILS.find(e => e.id === selectedEmail)?.from[0]}
                            </div>
                            <div>
                                <div className="text-sm font-bold text-white">{EMAILS.find(e => e.id === selectedEmail)?.from}</div>
                                <div className="text-xs text-gray-500">To: Me</div>
                            </div>
                        </div>
                    </div>
                    <span className="text-xs text-gray-500">{EMAILS.find(e => e.id === selectedEmail)?.time}</span>
                </div>
                <div className="p-6 text-gray-300 leading-relaxed text-sm">
                    {EMAILS.find(e => e.id === selectedEmail)?.body}
                    <br /><br />
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>
            </>
        ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-500">
                <MailIcon size={48} className="mb-4 opacity-50" />
                <p>Select an email to read</p>
            </div>
        )}
      </div>
    </div>
  );
};