import React, { useState, useRef, useEffect } from 'react';

export const Terminal: React.FC = () => {
  const [history, setHistory] = useState<string[]>(['Welcome to AshrafOS v2.0', 'Type "help" for available commands.']);
  const [input, setInput] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (cmd: string) => {
    const args = cmd.trim().split(' ');
    const command = args[0].toLowerCase();

    let response = '';

    switch (command) {
      case 'help':
        response = 'Available commands: help, clear, echo, ls, whoami, date, contact';
        break;
      case 'clear':
        setHistory([]);
        return;
      case 'echo':
        response = args.slice(1).join(' ');
        break;
      case 'ls':
        response = 'Documents  Downloads  Pictures  Music  Projects  Videos';
        break;
      case 'whoami':
        response = 'guest@ashraf-os';
        break;
      case 'date':
        response = new Date().toString();
        break;
      case 'contact':
        response = 'Email: contact@ashrafmorningstar.com\nGitHub: github.com/AshrafMorningstar';
        break;
      case '':
        response = '';
        break;
      default:
        response = `Command not found: ${command}`;
    }

    if (cmd) {
        setHistory(prev => [...prev, `guest@ashraf-os:~$ ${cmd}`, response].filter(Boolean));
    } else {
        setHistory(prev => [...prev, `guest@ashraf-os:~$ `]);
    }
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCommand(input);
      setInput('');
    }
  };

  return (
    <div className="h-full bg-[#1a1b26] text-[#a9b1d6] font-mono p-4 overflow-y-auto text-sm relative">
        <div className="scanline"></div>
      {history.map((line, i) => (
        <div key={i} className="whitespace-pre-wrap mb-1 leading-relaxed">{line}</div>
      ))}
      <div className="flex items-center gap-2">
        <span className="text-[#7aa2f7]">guest@ashraf-os:~$</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          className="bg-transparent outline-none flex-1 text-[#c0caf5] caret-[#7aa2f7]"
          autoFocus
        />
      </div>
      <div ref={endRef} />
    </div>
  );
};