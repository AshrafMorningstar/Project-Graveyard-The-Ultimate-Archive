import React from 'react';
import { useStore } from '../store';
import { Theme, WALLPAPERS } from '../types';
import { Monitor, Image as ImageIcon } from 'lucide-react';

export const Settings: React.FC = () => {
  const currentTheme = useStore((state) => state.theme);
  const setTheme = useStore((state) => state.setTheme);

  return (
    <div className="flex h-full bg-[#1e1e24] text-gray-200">
       {/* Sidebar */}
       <div className="w-48 bg-[#1a1a1e] border-r border-white/5 p-4 space-y-2 hidden sm:block">
           <div className="flex items-center gap-3 p-2 rounded-lg bg-blue-600 text-white">
                <Monitor size={18} />
                <span className="text-sm font-medium">Wallpaper</span>
           </div>
           {/* Mock items */}
           {['Display', 'Sound', 'Focus', 'Screen Time'].map(item => (
                <div key={item} className="px-3 py-2 text-sm text-gray-400 hover:text-white cursor-pointer">{item}</div>
           ))}
       </div>

       {/* Content */}
       <div className="flex-1 p-8 overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">Wallpaper</h2>
            
            <div className="grid grid-cols-2 gap-6">
                {(Object.values(Theme) as Theme[]).map((themeName) => (
                    <div 
                        key={themeName}
                        onClick={() => setTheme(themeName)}
                        className={`group relative aspect-video rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                            currentTheme === themeName ? 'border-blue-500 ring-4 ring-blue-500/20' : 'border-transparent hover:border-white/30'
                        }`}
                    >
                        <img 
                            src={WALLPAPERS[themeName]} 
                            alt={themeName} 
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
                        <div className="absolute bottom-3 left-3 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-white">
                            {themeName}
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="mt-8 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-200 text-sm">
                <p>Pro Tip: Changing the wallpaper updates the entire system ambiance.</p>
            </div>
       </div>
    </div>
  );
};
