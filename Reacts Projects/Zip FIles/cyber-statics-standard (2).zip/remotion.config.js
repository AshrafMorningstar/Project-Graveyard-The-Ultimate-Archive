module.exports = {
  // Minimal Remotion configuration placeholder
  // Change as needed for custom bundlers or plugins
};