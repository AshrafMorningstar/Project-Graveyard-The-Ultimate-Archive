import { registerRoot } from 'remotion';
import { RemotionRoot } from './Video';

registerRoot(RemotionRoot);