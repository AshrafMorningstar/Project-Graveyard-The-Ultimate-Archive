const axios = require('axios');
const fs = require('fs-extra');

const themes = ['cyberpunk', 'vaporwave', 'matrix', 'neon', 'minimal', 'chrome', 'hacker'];
const selectedTheme = themes[Math.floor(Math.random() * themes.length)];

async function generateStats() {
  const username = 'AshrafMorningstar';
  const userUrl = `https://api.github.com/users/${username}`;
  const response = await axios.get(userUrl);
  const data = {
    name: response.data.name || username,
    public_repos: response.data.public_repos,
    followers: response.data.followers,
    following: response.data.following,
    theme: selectedTheme
  };
  await fs.outputJson('output/stats.json', data, { spaces: 2 });
  console.log(`Generated stats with theme: ${selectedTheme}`);
}

generateStats();
