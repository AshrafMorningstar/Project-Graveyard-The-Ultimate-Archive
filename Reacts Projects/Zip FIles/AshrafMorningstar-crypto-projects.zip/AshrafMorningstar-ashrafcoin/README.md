# AshrafCoin (Simulated Blockchain)
A simple blockchain simulation in JavaScript. Each block records transactions and hashes like real chains.

GitHub: https://github.com/AshrafMorningstar