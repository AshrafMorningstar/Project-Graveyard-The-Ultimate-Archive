# GitHub Visual DNA
An AI-inspired, self-generating visual identity system for GitHub users based on public activity, repos, and profile structure. No two users will have the same 'DNA'.