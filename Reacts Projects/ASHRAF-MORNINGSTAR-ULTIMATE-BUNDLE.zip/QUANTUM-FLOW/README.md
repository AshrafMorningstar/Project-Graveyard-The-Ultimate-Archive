# ⚡ QUANTUM FLOW

Real-time Streaming Analytics Platform by @AshrafMorningstar
https://github.com/AshrafMorningstar