import { registerRoot } from "remotion";
import { Root } from "./Root";

registerRoot(Root);
