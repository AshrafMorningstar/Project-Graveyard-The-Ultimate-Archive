// Backend for AshrafMorningstar's BlockWeaveX (API gateway)
const express = require('express');
const app = express();
app.use(express.json());

app.get('/api/status', (_, res) => {
  res.json({
    app: 'BlockWeaveX',
    creator: 'AshrafMorningstar',
    status: 'online'
  });
});

app.listen(5001, () => console.log('BlockWeaveX API running on port 5001'));
