export type Theme = 'dark' | 'light';

export type AppSection = 'profile' | 'projects' | 'ai-lab' | 'games';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isThinking?: boolean;
  image?: string; // For displayed images in chat
  timestamp: number;
  sources?: Array<{
    title: string;
    url: string;
  }>;
}

export enum GeminiModelType {
  FAST = 'fast',
  THINKING = 'thinking',
  SEARCH = 'search',
  IMAGE_GEN = 'image-gen',
  VISION = 'vision'
}

export interface ImageGenConfig {
  size: '1K' | '2K' | '4K';
  aspectRatio: '1:1' | '16:9' | '4:3';
}

export interface QuantumParticle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
}
