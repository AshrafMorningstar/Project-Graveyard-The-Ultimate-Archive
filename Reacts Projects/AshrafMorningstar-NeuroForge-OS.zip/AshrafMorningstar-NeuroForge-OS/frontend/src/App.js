// App shell for NeuroForge OS
import React from 'react';
import Desktop from './components/Desktop';
function App() {
  return <Desktop />;
}
export default App;
