# NeuroForge OS

**Author:** AshrafMorningstar  
**GitHub:** https://github.com/AshrafMorningstar

A browser-based AI-augmented operating system with modular architecture, live window management, and a pluggable AI core.
