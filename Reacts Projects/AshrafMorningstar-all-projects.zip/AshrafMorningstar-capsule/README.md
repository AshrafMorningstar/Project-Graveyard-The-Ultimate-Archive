# AshrafMorningstar's GitHub Time Capsule
A time-capsule that snapshots public GitHub data every day and renders a historical scroll of development life.

GitHub: https://github.com/AshrafMorningstar