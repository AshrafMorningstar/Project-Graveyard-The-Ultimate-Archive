# SynapseFlow Studio

**Author:** AshrafMorningstar  
**GitHub:** https://github.com/AshrafMorningstar

A full-featured visual workflow automation builder inspired by n8n and Zapier.
